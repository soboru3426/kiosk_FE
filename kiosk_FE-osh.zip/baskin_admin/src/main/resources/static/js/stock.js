// 🔹 서버에서 지점별 데이터를 가져오는 함수 (예: fetch API 사용)
async function fetchBranchData(branch) {
    try {
        const response = await fetch(`/stock/data/${branch}`); // 서버에서 데이터 요청
        if (!response.ok) throw new Error('데이터를 불러오지 못했습니다.');

        const data = await response.json(); // JSON 변환
        updateTable(data); // 테이블 업데이트
    } catch (error) {
        console.error("Error fetching branch data:", error);
    }
}

// 🔹 테이블 업데이트 함수 (Pay 버튼 추가)
function updateTable(data) {
    const tableBody = document.querySelector(".stock-table-body");
    tableBody.innerHTML = ""; // 기존 데이터 초기화

    if (data.length === 0) {
        tableBody.innerHTML = "<tr><td colspan='7'>조회 내역이 없습니다.</td></tr>";
        return;
    }

    data.forEach((row, index) => {
        const newRow = `<tr>
            <td>${index + 1}</td>
            <td>${row.branchName}</td>
            <td>${row.menuName}</td>
            <td>${row.quantity}</td>
            <td>${row.productStatus}</td>
            <td class="order-status-cell" style="cursor:pointer;">${row.orderStatus}</td>
        </tr>`;
        tableBody.innerHTML += newRow;
    });

    // 🔹 Pay 버튼 클릭 이벤트 추가
    document.querySelectorAll(".order-status-cell").forEach(button => {
        button.addEventListener("click", function () {
            event.preventDefault(); // 기본 동작 방지 (페이지 이동 X)
    
            const stockId = this.parentElement.dataset.stockId;
            showStatusPanel(this, stockId);
        });
    });
    
}

function showStatusPanel(cell, stockId) {
    const panel = document.getElementById("status-panel");
    // 현재 셀의 위치를 기준으로 패널을 표시 (예: 셀 바로 아래)
    const rect = cell.getBoundingClientRect();
    panel.style.top = (rect.bottom + window.scrollY) + "px";
    panel.style.left = (rect.left + window.scrollX) + "px";
    panel.style.display = "block";
    panel.style.maxHeight = "100px";  // 슬라이드 열림

    // 현재 셀과 stockId를 저장 (업데이트 시 사용)
    panel.dataset.stockId = stockId;
    panel.currentCell = cell;
}

// 옵션 버튼 클릭 이벤트 (슬라이드 패널 내)
document.querySelectorAll(".status-option").forEach(button => {
    button.addEventListener("click", function () {
        const newStatus = this.dataset.status;
        const panel = document.getElementById("status-panel");
        const stockId = panel.dataset.stockId;

        // 팝업 모달 띄우기
        const modal = document.getElementById("confirmation-modal");
        modal.style.display = "flex";

        // 예 버튼 클릭 시 업데이트 실행
        document.getElementById("confirm-yes").onclick = function () {
            updateOrderStatus(stockId, newStatus);
            if (panel.currentCell) {
                panel.currentCell.textContent = newStatus;
            }
            closePanelAndModal();
        };

        // 아니오 버튼 클릭 시
        document.getElementById("confirm-no").onclick = function () {
            closePanelAndModal();
        };

        function closePanelAndModal() {
            modal.style.display = "none";
            panel.style.maxHeight = "0";
            setTimeout(() => { panel.style.display = "none"; }, 300);
        }
    });
});

// API 호출: 발주 상태 업데이트
async function updateOrderStatus(stockId, newStatus) {
    try {
        const response = await fetch(`/stock/update/${stockId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ orderStatus: newStatus })
        });
        if (!response.ok) throw new Error("상태 업데이트 실패");
        const result = await response.json();
        console.log("업데이트 성공:", result);
    } catch (error) {
        console.error("발주 상태 업데이트 오류:", error);
    }
}

// 지점 버튼 클릭 이벤트 설정 및 데이터 불러오기 (기존 코드 유지)
document.querySelectorAll(".branch-session button").forEach(button => {
    button.addEventListener("click", function() {
        document.querySelectorAll(".branch-session button").forEach(btn => btn.classList.remove("active"));
        this.classList.add("active");
        const branch = this.dataset.branch;
        fetchBranchData(branch);
    });
});

async function fetchBranchData(branch) {
    try {
        const response = await fetch(`/stock/data/${branch}`);
        if (!response.ok) throw new Error('데이터를 불러오지 못했습니다.');
        const data = await response.json();
        updateTable(data);
    } catch (error) {
        console.error("Error fetching branch data:", error);
    }
}

// 페이지 로드 시 첫 번째 지점 데이터 로드
document.addEventListener("DOMContentLoaded", function () {
    const firstBranch = document.querySelector(".branch-session button");
    if (firstBranch) firstBranch.click();
});