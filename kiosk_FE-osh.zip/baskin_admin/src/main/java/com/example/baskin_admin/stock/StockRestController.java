package com.example.baskin_admin.stock;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/stock")
public class StockRestController {

    @Autowired
    private StockService stockService;

    // PUT /stock/update/{stockId} : 발주 상태 업데이트 API
    @PutMapping("/update/{stockId}")
    public ResponseEntity<?> updateOrderStatus(@PathVariable Integer stockId, @RequestBody Map<String, String> request) {
        String newStatus = request.get("orderStatus");
        Stock updatedStock = stockService.updateOrderStatus(stockId, newStatus);
        if (updatedStock == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Stock not found");
        }
        return ResponseEntity.ok(updatedStock);
    }
}
