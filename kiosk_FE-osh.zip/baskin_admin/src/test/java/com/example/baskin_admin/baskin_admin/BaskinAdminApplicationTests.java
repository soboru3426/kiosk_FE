package com.example.baskin_admin.baskin_admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaskinAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}